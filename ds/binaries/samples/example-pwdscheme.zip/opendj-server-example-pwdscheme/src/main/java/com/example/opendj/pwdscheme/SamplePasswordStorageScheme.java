/*
 * The contents of this file are subject to the terms of the Common Development and
 * Distribution License (the License). You may not use this file except in compliance with the
 * License.
 *
 * You can obtain a copy of the License at legal/CDDLv1.0.txt. See the License for the
 * specific language governing permission and limitations under the License.
 *
 * When distributing Covered Software, include this CDDL Header Notice in each file and include
 * the License file at legal/CDDLv1.0.txt. If applicable, add the following below the CDDL
 * Header, with the fields enclosed by brackets [] replaced by your own identifying
 * information: "Portions Copyright [year] [name of copyright owner]".
 *
 * Copyright 2016-2025 Ping Identity Corporation.
 */
package com.example.opendj.pwdscheme;

import static com.example.opendj.pwdscheme.SamplePwdSchemeMessages.ERR_PWSCHEME_CANNOT_BASE64_DECODE_STORED_PASSWORD;
import static com.example.opendj.pwdscheme.SamplePwdSchemeMessages.ERR_PWSCHEME_DOES_NOT_SUPPORT_AUTH_PASSWORD;
import static com.example.opendj.pwdscheme.SamplePwdSchemeMessages.INFO_SAMPLE_PWDSCHEME_INIT;
import static org.forgerock.opendj.ldap.LdapException.constraintViolation;
import static org.forgerock.opendj.ldap.LdapException.unwillingToPerform;
import static org.opends.server.loggers.ServerLoggers.EXTENSIONS;

import java.security.MessageDigest;

import org.forgerock.opendj.ldap.Base64;
import org.forgerock.opendj.ldap.ByteString;
import org.forgerock.opendj.ldap.LdapException;
import org.opends.server.api.PasswordStorageScheme;
import org.opends.server.core.ServerContext;

import com.example.opendj.pwdscheme.server.SamplePasswordStorageSchemeCfg;

/**
 * This class defines an example of a Directory Server password storage scheme.
 * This scheme just base64 encode the password value.
 */
public final class SamplePasswordStorageScheme
        extends PasswordStorageScheme<SamplePasswordStorageSchemeCfg> {
    /** * The password storage scheme tag. */
    private static final String STORAGE_SCHEME_NAME_SAMPLE = "SAMPLE";

    /**
     * Creates a new instance of this password storage scheme.  Note that no initialization should be performed here,
     * as all initialization should be done in the <CODE>initializePasswordStorageScheme</CODE> method.
     */
    public SamplePasswordStorageScheme() {
        super();
    }

    @Override
    public void initializePasswordStorageScheme(SamplePasswordStorageSchemeCfg configuration,
                                                ServerContext serverContext) {
        // Initialize here MessageDigest, Random, Locks... that you may need
        EXTENSIONS.note(INFO_SAMPLE_PWDSCHEME_INIT);
    }

    @Override
    public String getStorageSchemeName() {
        return STORAGE_SCHEME_NAME_SAMPLE;
    }

    @Override
    public ByteString encodePassword(ByteString plaintext) {
        return ByteString.valueOfUtf8(Base64.encode(plaintext));
    }

    @Override
    public ByteString encodePasswordWithScheme(ByteString plaintext) {
        return ByteString.valueOfUtf8('{' + STORAGE_SCHEME_NAME_SAMPLE + '}' + encodePassword(plaintext));
    }

    @Override
    public boolean passwordMatches(ByteString plaintextPassword, ByteString storedPassword) {
        // Extract the hashed password from the stored value.
        byte[] decodedBytes;
        try {
            decodedBytes = Base64.decode(storedPassword.toString()).toByteArray();
        } catch (Exception e) {
            EXTENSIONS.error(ERR_PWSCHEME_CANNOT_BASE64_DECODE_STORED_PASSWORD, storedPassword, e);
            return false;
        }

        return MessageDigest.isEqual(plaintextPassword.toByteArray(), decodedBytes);
    }

    @Override
    public boolean supportsAuthPasswordSyntax() {
        return false;
    }

    @Override
    public ByteString encodeAuthPassword(ByteString plaintext) throws LdapException {
        throw unwillingToPerform(ERR_PWSCHEME_DOES_NOT_SUPPORT_AUTH_PASSWORD.get(getStorageSchemeName()));
    }

    @Override
    public boolean isReversible() {
        return true;
    }

    @Override
    public ByteString getPlaintextValue(ByteString storedPassword) throws LdapException {
        try {
            return Base64.decode(storedPassword.toString());
        } catch (Exception e) {
            throw constraintViolation(ERR_PWSCHEME_CANNOT_BASE64_DECODE_STORED_PASSWORD.get(storedPassword, e));
        }
    }

    @Override
    public boolean isStorageSchemeSecure() {
        return false;
    }

    /**
     * Generates an encoded password string from the given clear-text password.
     * This method is primarily intended for use when it is necessary to generate a password with the server offline
     * (e.g., when setting the initial root user password).
     *
     * @param passwordBytes The bytes that make up the clear-text password.
     * @return The encoded password string, including the scheme name in curly braces.
     */
    public static String encodeOffline(byte[] passwordBytes) {
        return "{" + STORAGE_SCHEME_NAME_SAMPLE + "}" + Base64.encode(passwordBytes);
    }
}
